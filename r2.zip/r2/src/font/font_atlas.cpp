#include <r2/font/font_atlas.h>
#include <r2/error.h>
#include <r2/renderer_base.h>
#include <r2/render_data.h>


r2_begin_

font_atlas::font_atlas(renderer_base* instance) noexcept
    : renderer_(instance),
      width_(kDefaultSize),
      height_(kDefaultSize)
{
}


bool font_atlas::check_side(std::uint32_t x, std::uint32_t y, std::uint32_t width, std::uint32_t height)
{
#if defined(_DEBUG)
    renderer_->assert_render_thread();
#endif

    const std::uint32_t x2 = x + width + padding_;
    const std::uint32_t y2 = y + height + padding_;
    if (x2 > width_ || y2 > height_) {
        return false;
    }

    for (const auto& r2 : rects_) {
        const bool intersects_x =
            r2.pos_x <= x2 &&
            r2.pos_x + r2.width + padding_ > x;

        const bool intersects_y =
            r2.pos_y <= y2 &&
            r2.pos_y + r2.height + padding_ > y;

        if (intersects_x &&
            intersects_y) {
            return false;
        }
    }

    return true;
}

bool font_atlas::find_rect(std::uint32_t width, std::uint32_t height, std::uint32_t& out_x, std::uint32_t& out_y)
{
#if defined(_DEBUG)
    renderer_->assert_render_thread();
#endif

    assert(width + padding_ * 2u <= width_);
    assert(height + padding_ * 2u <= height_);
    assert(width > 0u);
    assert(height > 0u);

    if (rects_.empty()) {
        out_x = padding_;
        out_y = padding_;
        return true;
    }

    for (const auto& r : rects_) {
        // check right
        std::uint32_t x = r.pos_x + r.width + padding_;
        std::uint32_t y = r.pos_y;

        if (check_side(x, y, width, height)) {
            out_x = x;
            out_y = y;
            return true;
        }

        // check left
        if (r.pos_x > width + padding_ * 2u) {
            x = r.pos_x - width - padding_;
            if (check_side(x, y, width, height)) {
                out_x = x;
                out_y = y;
                return true;
            }
        }

        // check below
        x = r.pos_x;
        y = r.pos_y + r.height + padding_;
        if (check_side(x, y, width, height)) {
            out_x = x;
            out_y = y;
            return true;
        }

        // check above
        if (r.pos_y > height + padding_ * 2u) {
            y = r.pos_y - height - padding_;
            if (check_side(x, y, width, height)) {
                out_x = x;
                out_y = y;
                return true;
            }
        }
    }

    return false;
}

bool font_atlas::add_white_pixel()
{
    constexpr std::uint8_t kWhitePixel = 0xFFu;
    auto rect_id = register_rect(1u, 1u);
    if (!rect_id) {
        return false;
    }

    write_data_init(*rect_id, &kWhitePixel, 1u);

    vec2 uv_min, uv_max;
    get_rect_uv(*rect_id, uv_min, uv_max);

    renderer_->shared_data_.uv_white_px = (uv_min + uv_max) * vec2(0.5f);

    return true;
}

bool font_atlas::add_tex_lines()
{
    if (!renderer_->flags().anti_aliased_lines_use_tex) {
        return true;
    }

    auto rect_id = register_rect(shared_data::kBakedLinesMaxWidth + 2u, shared_data::kBakedLinesMaxWidth + 1u);
    if (!rect_id) {
        return false;
    }

    const auto& r = this->get_rect(*rect_id);

    for (std::uint32_t n = 0u; n < shared_data::kBakedLinesMaxWidth + 1u; n++) {
        std::uint32_t y = n;
        std::uint32_t line_width = n;

        assert(line_width <= r.width);
        std::uint32_t pad_left = (r.width - line_width) / 2u;
        assert(pad_left + line_width <= r.width);
        std::uint32_t pad_right = r.width - (pad_left + line_width);

        assert(pad_left + line_width + pad_right == r.width && y < r.height);

        std::uint32_t* write_ptr = &data32_[r.pos_x + ((r.pos_y + y) * width_)];
        for (std::uint32_t i = 0u; i < pad_left; i++)
            *(write_ptr + i) = static_cast<std::uint32_t>(
                (color_u32)color::color::white().transparent());

        std::memset(
            write_ptr + pad_left, 
            0xFFu, 
            line_width * sizeof(std::uint32_t)
        );

        for (std::uint32_t i = 0u; i < pad_right; i++)
            *(write_ptr + pad_left + line_width + i) = static_cast<std::uint32_t>(
                (color_u32)color::color::white().transparent());

        vec2 uv0 = vec2(
            static_cast<float>(r.pos_x + pad_left - 1u), 
            static_cast<float>(r.pos_y + y)
        );
        vec2 uv1 = vec2(
            static_cast<float>(r.pos_x + pad_left + line_width + 1u),
            static_cast<float>(r.pos_y + y + 1u)
        );
        float half_v = (uv0.y + uv1.y) * 0.5f;
        renderer_->shared_data_.tex_uv_lines[n] = vec4(
            uv0.x / static_cast<float>(width_),
            half_v / static_cast<float>(height_), 
            uv1.x / static_cast<float>(width_),
            half_v / static_cast<float>(height_)
        );
    }

    return true;
}

bool font_atlas::add_shadow_tex()
{
    constexpr std::uint32_t kPadding = 1u;
    constexpr std::uint32_t kShadowTexSize = 32u;
    const std::uint32_t shadow_convex_size = kShadowTexSize + kPadding * 2u;
    auto rect_id = register_rect(shadow_convex_size, shadow_convex_size);
    if (!rect_id) {
        return false;
    }

    constexpr float kShadowFallowPower = 4.f;
    constexpr float kShadowDistanceFieldOffset = 3.8f;

    std::vector<std::uint8_t> data(shadow_convex_size * shadow_convex_size);

    const std::uint32_t side_min = kPadding;
    const std::uint32_t side_max = shadow_convex_size - kPadding - 1u;

    // calculate highest value for scale
    const float max_size = r2::vec2(
        static_cast<float>(side_max - side_min)
    ).length();

    auto calc_shadow = [&](float dist) 
        {
            float alpha = 1.f - std::min(
                std::max(dist + kShadowDistanceFieldOffset, 0.f) /
                std::max(max_size + kShadowDistanceFieldOffset, 0.001f),
                1.f
            );
            return std::pow(alpha, kShadowFallowPower);
        };

    float scale = calc_shadow(0.f);
    scale = (scale > 0.f) ? 1.f / scale : 1.f;

    // build
    const vec2 target_point = vec2(static_cast<float>(side_max));

    for (std::uint32_t y = 0u; y < shadow_convex_size; y++) {
        for (std::uint32_t x = 0u; x < shadow_convex_size; x++) {
            const std::uint32_t clamped_x = std::clamp(x, side_min, side_max);
            const std::uint32_t clamped_y = std::clamp(y, side_min, side_max);

            const float dist = (vec2(
                static_cast<float>(clamped_x),
                static_cast<float>(clamped_y)
            ) - target_point).length();

            float alpha = calc_shadow(dist) * scale;
            data[x + (y * shadow_convex_size)] =
                static_cast<std::uint8_t>(std::clamp(alpha * 255.f, 0.f, 255.f));
        }
    }

    write_data_init(*rect_id, data.data(), data.size());

    vec2 uv_min, uv_max;
    get_rect_uv(*rect_id, uv_min, uv_max);

    const vec2 offset = vec2(
        static_cast<float>(kPadding) * 1.f / static_cast<float>(width_),
        static_cast<float>(kPadding) * 1.f / static_cast<float>(height_)
    );

    renderer_->shared_data_.shadow_uvs = vec4(
        uv_min.x + offset.x, uv_min.y + offset.y,
        uv_max.x - offset.x, uv_max.y - offset.y
    );

    return true;
}

std::optional<std::uint32_t> font_atlas::register_rect(std::uint32_t width, std::uint32_t height)
{
#if defined(_DEBUG)
    renderer_->assert_render_thread();
#endif

    std::uint32_t x, y;
    if (!find_rect(width, height, x, y)) {
        return std::nullopt;
    }

    if (!free_rect_slots_.empty()) {
        auto idx = free_rect_slots_.back();
        free_rect_slots_.pop_back();

        rects_[idx].pos_x = x;
        rects_[idx].pos_y = y;
        rects_[idx].width = width;
        rects_[idx].height = height;
        return idx;
    }
    // push if no empty rect found
    rects_.emplace_back(x, y, width, height);

    return static_cast<std::uint32_t>(rects_.size()) - 1u;
}

void font_atlas::remove_rect(std::uint32_t id)
{
#if defined(_DEBUG)
    renderer_->assert_render_thread();
#endif

    if (id >= rects_.size()) {
        // maybe show a warning here
        return;
    }

    // make "invisible" to "find_rect"
    rects_[id].pos_x = 0;
    rects_[id].pos_y = 0;
    rects_[id].width = 0;
    rects_[id].height = 0;

    free_rect_slots_.push_back(id);
}

void font_atlas::get_rect_uv(std::uint32_t id, vec2& uv_min, vec2& uv_max) const
{
#if defined(_DEBUG)
    renderer_->assert_render_thread();
#endif

    assert(id < rects_.size());

    auto& r = rects_[id];

    uv_min.x = static_cast<float>(r.pos_x) / static_cast<float>(width_);
    uv_min.y = static_cast<float>(r.pos_y) / static_cast<float>(height_);

    uv_max.x = uv_min.x + static_cast<float>(r.width) / static_cast<float>(width_);
    uv_max.y = uv_min.y + static_cast<float>(r.height) / static_cast<float>(height_);
}

atlas_rect font_atlas::get_rect(std::uint32_t id)
{
#if defined(_DEBUG)
    renderer_->assert_render_thread();
#endif

    assert(id < rects_.size());

    return rects_[id];
}

void font_atlas::write_data(std::uint32_t id, const std::uint8_t* data, std::size_t size)
{
    std::vector<std::uint32_t> rgba(size);

    for (std::uint32_t i = 0; i < size; ++i) {
        constexpr std::uint8_t white = 0xffu;
        rgba[i] = white | (white << 8) | (white << 16) | (data[i] << 24);
    }

    return write_data(id, rgba.data(), rgba.size());
}

void font_atlas::write_data(std::uint32_t id, const std::uint32_t* data, std::size_t size)
{
    assert(renderer_->render_data());
    assert(renderer_->render_data()->font_texture);

    atlas_rect r = get_rect(id);
    assert(r.width * r.height == size);
    (void)size;

    renderer_->render_data()->font_texture->update(
        data,
        r.width * sizeof(std::uint32_t),
        r.pos_x,
        r.pos_y,
        r.width,
        r.height
    );
}

void font_atlas::write_data_init(std::uint32_t id, const std::uint8_t* data, std::size_t size)
{
#if defined(_DEBUG)
    renderer_->assert_render_thread();
#endif

    (void)size;

    atlas_rect rect = get_rect(id);

    assert(rect.width * rect.height == size);

    for (std::uint32_t y = 0u; y < rect.height; ++y) {
        const uint8_t* src_row = data + y * rect.width;
        uint32_t* dst_row = data32_.data() + (rect.pos_y + y) *
            width_ + rect.pos_x;
        for (std::uint32_t x = 0u; x < rect.width; x++) {
            const std::uint8_t byte = src_row[x];
            constexpr std::uint8_t white = 0xffu;
            dst_row[x] = white | (white << 8) | (white << 16) | (byte << 24);
        }
    }
}

bool font_atlas::build()
{
    data32_.resize(width_ * height_);

    if (!add_white_pixel()) {
        return false;
    }

    if (!add_tex_lines()) {
        return false;
    }

    if (!add_shadow_tex()) {
        return false;
    }

    return true;
}

r2_end_